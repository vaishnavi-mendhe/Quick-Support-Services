import os
import django
from django.test import Client

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
django.setup()

from django.contrib.auth.models import User

# Check if we can create a user and hit admin-dashboard
client = Client()

try:
    user = User.objects.get(username='test_admin_script')
except User.DoesNotExist:
    user = User.objects.create_user(username='test_admin_script', password='test_password')
    user.profile.role = 'admin'
    user.profile.save()

client.login(username='test_admin_script', password='test_password')
response = client.get('/admin-dashboard/')
print("Status code:", response.status_code)

if response.status_code != 200:
    print("Content:", response.content.decode('utf-8')[:500])
else:
    print("IT WORKS!")
