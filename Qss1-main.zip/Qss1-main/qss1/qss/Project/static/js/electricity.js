// JavaScript for Electricity Service Page
document.addEventListener('DOMContentLoaded', function () {
    // Set minimum date for date picker to today
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const todayStr = `${yyyy}-${mm}-${dd}`;
    document.getElementById('date').min = todayStr;

    // Initialize booking data object
    const bookingData = {
        service: '',
        price: 0,
        date: '',
        time: '',
        urgency: '',
        name: '',
        email: '',
        contact: '',
        address: '',
        problemDescription: '',
        powerAvailable: false
    };

    // Hero book now button
    document.getElementById('heroBookBtn').addEventListener('click', function () {
        document.getElementById('bookingCard').scrollIntoView({ behavior: 'smooth' });
    });

    // Service selection
    const serviceOptions = document.querySelectorAll('.service-option');
    serviceOptions.forEach(option => {
        option.addEventListener('click', function () {
            serviceOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            bookingData.service = this.querySelector('h5').textContent;
            bookingData.price = parseInt(this.getAttribute('data-price'));
            document.querySelector('.amount').textContent = bookingData.price;
        });
    });

    // Urgency selection
    const urgencySelect = document.getElementById('urgency');
    urgencySelect.addEventListener('change', function () {
        bookingData.urgency = this.options[this.selectedIndex].text;
        if (bookingData.service && bookingData.price) {
            adjustPriceByUrgency();
        }
    });

    function adjustPriceByUrgency() {
        const urgency = urgencySelect.value;
        let multiplier = 1;
        switch (urgency) {
            case 'urgent': multiplier = 1.5; break;
            case 'emergency': multiplier = 2; break;
        }
        const basePrice = parseInt(document.querySelector('.service-option.active').getAttribute('data-price'));
        bookingData.price = Math.round(basePrice * multiplier);
        document.querySelector('.amount').textContent = bookingData.price;
    }

    // Power availability checkbox
    document.getElementById('powerAvailable').addEventListener('change', function () {
        bookingData.powerAvailable = this.checked;
    });

    // Step navigation
    const progressSteps = document.querySelectorAll('.progress-step');
    let currentStep = 1;

    document.querySelectorAll('.btn-next').forEach(button => {
        button.addEventListener('click', function () {
            const nextStep = parseInt(this.getAttribute('data-next'));
            if (validateStep(currentStep)) {
                document.querySelector(`.progress-step[data-step="${currentStep}"]`).classList.remove('active');
                document.querySelector(`.progress-step[data-step="${nextStep}"]`).classList.add('active');
                document.getElementById(`step${currentStep}`).classList.remove('active');
                document.getElementById(`step${nextStep}`).classList.add('active');
                if (nextStep === 4) updateSummary();
                currentStep = nextStep;
            }
        });
    });

    document.querySelectorAll('.btn-prev').forEach(button => {
        button.addEventListener('click', function () {
            const prevStep = parseInt(this.getAttribute('data-prev'));
            document.querySelector(`.progress-step[data-step="${currentStep}"]`).classList.remove('active');
            document.querySelector(`.progress-step[data-step="${prevStep}"]`).classList.add('active');
            document.getElementById(`step${currentStep}`).classList.remove('active');
            document.getElementById(`step${prevStep}`).classList.add('active');
            currentStep = prevStep;
        });
    });

    // Validation per step
    function validateStep(step) {
        switch (step) {
            case 1:
                if (!bookingData.service) { alert('Please select a service'); return false; }
                return true;
            case 2:
                const date = document.getElementById('date').value;
                const time = document.getElementById('timeSlot').value;
                if (!date) { alert('Select a date'); return false; }
                if (!time) { alert('Select a time slot'); return false; }
                bookingData.date = date;
                bookingData.time = time;
                bookingData.urgency = urgencySelect.options[urgencySelect.selectedIndex].text;
                return true;
            case 3:
                const name = document.getElementById('name').value.trim();
                const email = document.getElementById('email').value.trim();
                const contact = document.getElementById('contact').value.trim();
                const address = document.getElementById('address').value.trim();
                const problemDescription = document.getElementById('problemDescription').value.trim();
                if (name.length < 2) { alert('Enter your full name'); return false; }
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { alert('Enter valid email'); return false; }
                if (!/^[6-9]\d{9}$/.test(contact)) { alert('Enter valid 10-digit mobile number'); return false; }
                if (address.length < 10) { alert('Enter complete address'); return false; }
                if (problemDescription.length < 10) { alert('Describe your problem in detail'); return false; }
                bookingData.name = name;
                bookingData.email = email;
                bookingData.contact = contact;
                bookingData.address = address;
                bookingData.problemDescription = problemDescription;
                bookingData.powerAvailable = document.getElementById('powerAvailable').checked;
                return true;
            default: return true;
        }
    }

    // Update order summary
    function updateSummary() {
        document.getElementById('summary-service').textContent = bookingData.service;
        document.getElementById('summary-urgency').textContent = bookingData.urgency;
        document.getElementById('summary-datetime').textContent =
            `${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}`;
        document.getElementById('summary-amount').textContent = `₹${bookingData.price}`;
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    function getTimeSlotText(value) {
        const slots = {
            '9-12': '9:00 AM - 12:00 PM',
            '12-3': '12:00 PM - 3:00 PM',
            '3-6': '3:00 PM - 6:00 PM',
            '6-9': '6:00 PM - 9:00 PM'
        };
        return slots[value] || value;
    }

    // ---------- Payment Handling ----------
    const cardPayment = document.getElementById("card-payment");
    const cardDetails = document.getElementById("cardDetails");
    const upiPayment = document.getElementById("upi-payment");
    const upiDetails = document.getElementById("upiDetails");
    const upiMethod = document.getElementById("upiMethod");
    const upiQrSection = document.getElementById("upiQrSection");
    const upiIdSection = document.getElementById("upiIdSection");
    const upiIdInput = document.getElementById("upiId");
    const paymentOptions = document.querySelectorAll('input[name="payment"]');

    // Hide all by default except card (initially selected)
    function togglePaymentSections() {
        if (cardPayment.checked) {
            cardDetails.style.display = "block";
            upiDetails.style.display = "none";
        } else if (upiPayment.checked) {
            cardDetails.style.display = "none";
            upiDetails.style.display = "block";
        } else {
            // COD
            cardDetails.style.display = "none";
            upiDetails.style.display = "none";
        }
    }

    paymentOptions.forEach(opt => {
        opt.addEventListener("change", togglePaymentSections);
    });

    // Initialize on load
    togglePaymentSections();

    // Handle UPI method choice
    upiMethod.addEventListener("change", function () {
        if (this.value === "qr") {
            upiQrSection.style.display = "block";
            upiIdSection.style.display = "none";
        } else if (this.value === "id") {
            upiIdSection.style.display = "block";
            upiQrSection.style.display = "none";
        } else {
            upiQrSection.style.display = "none";
            upiIdSection.style.display = "none";
        }
    });

    // ---------- Confirm Payment ----------
    document.getElementById("confirmPayment").addEventListener("click", function () {
        const selectedPayment = document.querySelector('input[name="payment"]:checked').value;

        if (selectedPayment === "upi") {
            const method = upiMethod.value;
            if (!method) {
                alert("Please select a UPI payment method");
                return;
            }

            if (method === "id") {
                const upiRegex = /^[\w.\-]{2,256}@[a-zA-Z]{2,64}$/;
                if (!upiRegex.test(upiIdInput.value.trim())) {
                    alert("Please enter a valid UPI ID (e.g., example@upi)");
                    return;
                }
            }
        }

        // Save booking data
        localStorage.setItem("electricityBookingData", JSON.stringify(bookingData));

        // Show order summary
        showConfirmation();
    });

    // Show Confirmation & Download Receipt 
    function showConfirmation() {
        const bookingCard = document.getElementById("bookingCard");
        bookingCard.innerHTML = `
            <div class="confirmation-step">
                <i class="fas fa-check-circle confirmation-icon"></i>
                <h3>Payment Successful!</h3>
                <div class="confirmation-details">
                    <p><strong>Service:</strong> ${bookingData.service}</p>
                    <p><strong>Urgency:</strong> ${bookingData.urgency}</p>
                    <p><strong>Date & Time:</strong> ${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}</p>
                    <p><strong>Amount Paid:</strong> ₹${bookingData.price}</p>
                    <p><strong>Name:</strong> ${bookingData.name}</p>
                    <p><strong>Contact:</strong> ${bookingData.contact}</p>
                    <p><strong>Address:</strong> ${bookingData.address}</p>
                </div>
                <button class="btn-download" id="downloadReceipt">Download Receipt (PDF)</button>
                <button class="btn-cancel" id="cancelBookingBtn">Cancel Booking</button>
                <button class="btn-reschedule" id="rescheduleBookingBtn">Reschedule</button>
                <button class="btn-home" onclick="window.location.href='/'">Go Home</button>
            </div>
        `;
        document.getElementById('downloadReceipt').addEventListener('click', downloadReceiptPDF);
        attachCancelReschedule();

        function downloadReceiptPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            doc.setFontSize(18);
            doc.setTextColor(40, 40, 40);
            doc.text("Quick Support Services", 20, 20);
            doc.setFontSize(12);
            doc.text("Electricity Service Receipt", 20, 28);

            doc.setDrawColor(150);
            doc.line(20, 32, 190, 32);

            doc.setFontSize(12);
            doc.text(`Customer: ${bookingData.name}`, 20, 45);
            doc.text(`Email: ${bookingData.email}`, 20, 52);
            doc.text(`Contact: ${bookingData.contact}`, 20, 59);

            doc.text(`Service: ${bookingData.service}`, 20, 72);
            doc.text(`Urgency: ${bookingData.urgency}`, 20, 79);
            doc.text(`Date & Time: ${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}`, 20, 86);
            doc.text(`Address: ${bookingData.address}`, 20, 93, { maxWidth: 170 });

            doc.setFontSize(14);
            doc.text(`Amount Paid: ₹${bookingData.price}`, 20, 110);

            doc.setFontSize(10);
            doc.setTextColor(100);
            doc.text("Thank you for choosing Quick Support Services!", 20, 130);

            doc.save("Electricity_Receipt.pdf");
        };
    }

    // CANCEL & RESCHEDULE HANDLER 
    function attachCancelReschedule() {
        const cancelBtn = document.getElementById('cancelBookingBtn');
        const rescheduleBtn = document.getElementById('rescheduleBookingBtn');

        if (cancelBtn) cancelBtn.addEventListener('click', () => {
            if (confirm("Are you sure you want to cancel this booking?")) {
                localStorage.removeItem('electricityBookingData');
                alert("Booking canceled!");
                window.location.reload();
            }
        });

        if (rescheduleBtn) rescheduleBtn.addEventListener('click', () => {
            showRescheduleForm();
        });
    }

    function showRescheduleForm() {
        const card = document.getElementById('bookingCard');
        card.innerHTML = `
            <div class="reschedule-form">
                <h3>Reschedule Booking</h3>
                <label for="newDate">Select New Date:</label>
                <input type="date" id="newDate" min="${todayStr}" value="${bookingData.date}">
                <label for="newTime">Select New Time Slot:</label>
                <select id="newTime">
                    <option value="9-12" ${bookingData.time==='9-12'?'selected':''}>9:00 AM - 12:00 AM</option>
                    <option value="12-3" ${bookingData.time==='12-3'?'selected':''}>12:00 AM - 3:00 PM</option>
                    <option value="3-6" ${bookingData.time==='3-6'?'selected':''}>3:00 PM - 6:00 PM</option>
                    <option value="6-9" ${bookingData.time==='6-9'?'selected':''}>6:00 PM - 9:00 PM</option>
                </select>
                <button id="confirmReschedule" class="btn-confirm">Confirm</button>
                <button id="cancelReschedule" class="btn-cancel">Cancel</button>
            </div>
        `;

        document.getElementById('confirmReschedule').addEventListener('click', () => {
            const newDate = document.getElementById('newDate').value;
            const newTime = document.getElementById('newTime').value;
            if (!newDate || !newTime) { alert("Select both date and time"); return; }
            bookingData.date = newDate;
            bookingData.time = newTime;
            localStorage.setItem('electricityBookingData', JSON.stringify(bookingData));
            alert(`Booking rescheduled to ${formatDate(newDate)} | ${getTimeSlotText(newTime)}`);
            showConfirmation(); // <-- confirmation updated with new date/time
        });

        document.getElementById('cancelReschedule').addEventListener('click', () => {
            showConfirmation();
        });
    }
    }
);
// FAQ accordion functionality
    const faqQuestions = document.querySelectorAll('.faq-question');
    faqQuestions.forEach(question => {
        question.addEventListener('click', function() {
            this.classList.toggle('active');
            const answer = this.nextElementSibling;
            answer.classList.toggle('show');
        });
    });

    // Pricing plan selection
    const planButtons = document.querySelectorAll('.btn-select');
    planButtons.forEach(button => {
        button.addEventListener('click', function() {
            const plan = this.parentElement.querySelector('h3').textContent;
            alert(`You've selected the ${plan}. You'll be redirected to booking.`);
            document.getElementById('bookingCard').scrollIntoView({ behavior: 'smooth' });
        });
    });

    // Add safety information for electrical work
    const safetyInfo = document.createElement('div');
    safetyInfo.className = 'safety-info';
    safetyInfo.innerHTML = `
        <h5><i class="fas fa-exclamation-triangle"></i> Electrical Safety Information</h5>
        <ul>
            <li>Do not attempt electrical repairs yourself</li>
            <li>Keep children and pets away from electrical work areas</li>
            <li>Ensure proper ventilation during electrical work</li>
            <li>Our electricians will follow all safety protocols</li>
        </ul>
    `;
    document.querySelector('.electricity-booking').insertBefore(safetyInfo, document.querySelector('.booking-progress'));
