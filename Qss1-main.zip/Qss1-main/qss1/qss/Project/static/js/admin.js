// Admin Dashboard - Complete Functionality
class AdminDashboard {
    constructor() {
        this.init();
    }

    init() {
        this.checkAuth();
        this.initSidebar();
        this.initTheme();
        this.initComponents();
        this.initModals();
        this.loadPageData();
        this.initEventListeners();
    }

    checkAuth() {
        // Disabled client-side auth tracking. Django server now handles all authentication and redirects natively.
    }

    updateUserInfo() {
        const user = JSON.parse(localStorage.getItem('adminUser') || '{}');
        const nameElements = document.querySelectorAll('.admin-name');
        const roleElements = document.querySelectorAll('.admin-role');
        
        nameElements.forEach(el => {
            if (user.name) el.textContent = user.name;
        });
        
        roleElements.forEach(el => {
            if (user.role) el.textContent = user.role;
        });
    }

    initSidebar() {
        const toggleBtn = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('adminSidebar');
        
        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', () => {
                sidebar.classList.toggle('collapsed');
                document.body.classList.toggle('sidebar-collapsed');
            });
        }
        
        // Set active nav item based on current page
        this.setActiveNavItem();
    }

    setActiveNavItem() {
        const currentPage = window.location.pathname.split('/').pop() || 'admin.html';
        const navItems = document.querySelectorAll('.nav-item');
        
        navItems.forEach(item => {
            const link = item.querySelector('a');
            if (link) {
                const href = link.getAttribute('href');
                if (href === currentPage) {
                    item.classList.add('active');
                } else {
                    item.classList.remove('active');
                }
            }
        });
    }

    initTheme() {
        const themeToggle = document.getElementById('adminThemeToggle');
        
        if (themeToggle) {
            // Check saved theme
            if (localStorage.getItem('adminDarkMode') === 'true') {
                document.body.classList.add('dark-mode');
                themeToggle.checked = true;
            }
            
            themeToggle.addEventListener('change', (e) => {
                if (e.target.checked) {
                    document.body.classList.add('dark-mode');
                    localStorage.setItem('adminDarkMode', 'true');
                } else {
                    document.body.classList.remove('dark-mode');
                    localStorage.setItem('adminDarkMode', 'false');
                }
            });
        }
    }

    initComponents() {
        this.initCharts();
        this.initDataTables();
        this.initNotifications();
        this.initSearch();
        this.initProfileDropdown();
    }

    initCharts() {
        // Only initialize if charts exist on page
        if (document.getElementById('bookingsChart')) this.initBookingsChart();
        if (document.getElementById('revenueChart')) this.initRevenueChart();
        if (document.getElementById('categoriesChart')) this.initCategoriesChart();
        if (document.getElementById('providersChart')) this.initProvidersChart();
    }

    initBookingsChart() {
        const ctx = document.getElementById('bookingsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Bookings',
                    data: [32, 45, 38, 52, 47, 60, 55],
                    borderColor: '#4361ee',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } }
            }
        });
    }

    initRevenueChart() {
        const ctx = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Revenue',
                    data: [8500, 9200, 10200, 9800, 11500, 12589],
                    backgroundColor: '#4CAF50'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } }
            }
        });
    }

    initCategoriesChart() {
        const ctx = document.getElementById('categoriesChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Plumbing', 'Electrical', 'Cleaning', 'Home Repair', 'Others'],
                datasets: [{
                    data: [35, 25, 20, 15, 5],
                    backgroundColor: ['#4361ee', '#4CAF50', '#FF9800', '#F44336', '#00BCD4']
                }]
            }
        });
    }

    initProvidersChart() {
        const ctx = document.getElementById('providersChart').getContext('2d');
        new Chart(ctx, {
            type: 'horizontalBar',
            data: {
                labels: ['Alex J.', 'Maria G.', 'David C.', 'John S.', 'Sarah L.'],
                datasets: [{
                    data: [128, 96, 201, 78, 145],
                    backgroundColor: '#FF9800'
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                plugins: { legend: { display: false } }
            }
        });
    }

    initDataTables() {
        // Initialize DataTables if jQuery DataTables is included
        if (typeof $ !== 'undefined' && $.fn.DataTable) {
            $('.data-table').DataTable({
                pageLength: 10,
                responsive: true
            });
        }
    }

    initNotifications() {
        const notificationIcon = document.querySelector('.notification-icon');
        const notificationPanel = document.getElementById('notificationPanel');
        
        if (notificationIcon && notificationPanel) {
            notificationIcon.addEventListener('click', (e) => {
                e.stopPropagation();
                notificationPanel.style.display = 
                    notificationPanel.style.display === 'block' ? 'none' : 'block';
            });
            
            document.addEventListener('click', (e) => {
                if (!notificationIcon.contains(e.target) && !notificationPanel.contains(e.target)) {
                    notificationPanel.style.display = 'none';
                }
            });
        }
        
        // Mark as read functionality
        document.querySelectorAll('.mark-as-read').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const notification = e.target.closest('.notification-item');
                notification.classList.remove('unread');
                this.updateNotificationCount();
            });
        });
        
        // Mark all as read
        const markAllBtn = document.getElementById('markAllRead');
        if (markAllBtn) {
            markAllBtn.addEventListener('click', () => {
                document.querySelectorAll('.notification-item.unread').forEach(item => {
                    item.classList.remove('unread');
                });
                this.updateNotificationCount();
            });
        }
    }

    updateNotificationCount() {
        const unreadCount = document.querySelectorAll('.notification-item.unread').length;
        const badge = document.querySelector('.notification-badge');
        
        if (badge) {
            if (unreadCount > 0) {
                badge.textContent = unreadCount;
                badge.style.display = 'flex';
            } else {
                badge.style.display = 'none';
            }
        }
    }

    initSearch() {
        const searchInput = document.getElementById('adminSearch');
        if (!searchInput) return;
        
        searchInput.addEventListener('input', debounce((e) => {
            this.performSearch(e.target.value);
        }, 300));
    }

    performSearch(query) {
        if (query.length < 2) return;
        
        // Simulate API call
        console.log('Searching for:', query);
        // In real app, make API call and display results
    }

    initProfileDropdown() {
        const profile = document.getElementById('adminProfile');
        const dropdown = profile ? profile.querySelector('.dropdown-menu') : null;
        
        if (profile && dropdown) {
            profile.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.style.display = 
                    dropdown.style.display === 'block' ? 'none' : 'block';
            });
            
            document.addEventListener('click', (e) => {
                if (!profile.contains(e.target)) {
                    dropdown.style.display = 'none';
                }
            });
        }
        
        // Logout functionality
        const logoutBtn = document.getElementById('adminLogout');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showConfirmation('Logout', 'Are you sure you want to logout?', () => {
                    localStorage.removeItem('adminToken');
                    localStorage.removeItem('adminUser');
                    window.location.href = '/login/';
                });
            });
        }
    }

    initModals() {
        // Close modals when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });
        
        // Close buttons
        document.querySelectorAll('.modal-close, .btn-cancel').forEach(btn => {
            btn.addEventListener('click', () => {
                const modal = btn.closest('.modal');
                if (modal) modal.style.display = 'none';
            });
        });
        
        // Initialize specific modals
        this.initAddServiceModal();
        this.initSendNotificationModal();
        this.initAddProviderModal();
        this.initAddUserModal();
        this.initAddCategoryModal();
    }

    initAddServiceModal() {
        const form = document.getElementById('addServiceForm');
        if (!form) return;
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);
            
            // Simulate API call
            setTimeout(() => {
                this.showToast('Service added successfully!', 'success');
                this.closeModal('addService');
                form.reset();
                
                // Refresh services list if on services page
                if (window.location.pathname.includes('admin-services')) {
                    this.loadServices();
                }
            }, 1000);
        });
    }

    initSendNotificationModal() {
        const form = document.getElementById('sendNotificationForm');
        if (!form) return;
        
        const recipientType = document.getElementById('recipientType');
        const specificUsersGroup = document.getElementById('specificUsersGroup');
        
        if (recipientType && specificUsersGroup) {
            recipientType.addEventListener('change', (e) => {
                specificUsersGroup.style.display = e.target.value === 'specific' ? 'block' : 'none';
            });
        }
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            // Simulate sending notification
            setTimeout(() => {
                this.showToast('Notification sent successfully!', 'success');
                this.closeModal('sendNotification');
                form.reset();
            }, 1000);
        });
    }

    initAddProviderModal() {
        const form = document.getElementById('addProviderForm');
        if (!form) return;
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            // Simulate API call
            setTimeout(() => {
                this.showToast('Provider added successfully!', 'success');
                this.closeModal('addProvider');
                form.reset();
            }, 1000);
        });
    }

    initAddUserModal() {
        const form = document.getElementById('addUserForm');
        if (!form) return;
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            // Simulate API call
            setTimeout(() => {
                this.showToast('User added successfully!', 'success');
                this.closeModal('addUser');
                form.reset();
            }, 1000);
        });
    }

    initAddCategoryModal() {
        const form = document.getElementById('addCategoryForm');
        if (!form) return;
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            // Simulate API call
            setTimeout(() => {
                this.showToast('Category added successfully!', 'success');
                this.closeModal('addCategory');
                form.reset();
            }, 1000);
        });
    }

    loadPageData() {
        const page = window.location.pathname.split('/').pop() || 'admin.html';
        
        switch(page) {
            case 'admin-users.html':
                this.loadUsers();
                break;
            case 'admin-providers.html':
                this.loadProviders();
                break;
            case 'admin-services.html':
                this.loadServices();
                break;
            case 'admin-categories.html':
                this.loadCategories();
                break;
            case 'admin-bookings.html':
                this.loadBookings();
                break;
            case 'admin-payments.html':
                this.loadPayments();
                break;
            case 'admin-feedback.html':
                this.loadFeedback();
                break;
            case 'admin-tickets.html':
                this.loadTickets();
                break;
            case 'admin.html':
                this.loadDashboardData();
                break;
        }
    }

    async loadUsers() {
        // Simulate API call
        const users = [
            { id: 1, name: 'John Doe', email: 'john@example.com', phone: '123-456-7890', status: 'active', joined: '2023-01-15' },
            { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '123-456-7891', status: 'active', joined: '2023-02-20' },
            { id: 3, name: 'Mike Johnson', email: 'mike@example.com', phone: '123-456-7892', status: 'inactive', joined: '2023-03-10' }
        ];
        
        this.renderTable('usersTable', users, ['name', 'email', 'phone', 'status', 'joined']);
    }

    async loadProviders() {
        const providers = [
            { id: 1, name: 'Alex Johnson', service: 'Plumbing', rating: 4.9, status: 'verified', bookings: 128 },
            { id: 2, name: 'Maria Garcia', service: 'Electrical', rating: 4.8, status: 'pending', bookings: 96 },
            { id: 3, name: 'David Chen', service: 'Cleaning', rating: 4.7, status: 'verified', bookings: 201 }
        ];
        
        this.renderTable('providersTable', providers, ['name', 'service', 'rating', 'status', 'bookings']);
    }

    async loadServices() {
        const services = [
            { id: 1, name: 'Plumbing Repair', category: 'Plumbing', price: '$80-150', status: 'active', bookings: 245 },
            { id: 2, name: 'Electrical Wiring', category: 'Electrical', price: '$100-200', status: 'active', bookings: 189 },
            { id: 3, name: 'Deep Cleaning', category: 'Cleaning', price: '$120-250', status: 'active', bookings: 312 }
        ];
        
        this.renderTable('servicesTable', services, ['name', 'category', 'price', 'status', 'bookings']);
    }

    async loadBookings() {
        const bookings = [
            { id: 'BKT-7894', customer: 'John Smith', service: 'Plumbing', provider: 'Alex Johnson', date: '2023-12-01', time: '10:30 AM', status: 'completed', amount: '$120' },
            { id: 'BKT-7893', customer: 'Sarah Lee', service: 'Electrical', provider: 'Maria Garcia', date: '2023-12-01', time: '11:00 AM', status: 'in-progress', amount: '$150' },
            { id: 'BKT-7892', customer: 'Mike Johnson', service: 'Cleaning', provider: 'David Chen', date: '2023-12-02', time: '1:30 PM', status: 'pending', amount: '$200' }
        ];
        
        this.renderTable('bookingsTable', bookings, ['id', 'customer', 'service', 'provider', 'date', 'time', 'status', 'amount']);
    }

    async loadPayments() {
        const payments = [
            { id: 'PAY-1234', booking: 'BKT-7894', customer: 'John Smith', amount: '$120', method: 'Credit Card', status: 'completed', date: '2023-12-01' },
            { id: 'PAY-1235', booking: 'BKT-7893', customer: 'Sarah Lee', amount: '$150', method: 'PayPal', status: 'pending', date: '2023-12-01' },
            { id: 'PAY-1236', booking: 'BKT-7892', customer: 'Mike Johnson', amount: '$200', method: 'Credit Card', status: 'refunded', date: '2023-12-02' }
        ];
        
        this.renderTable('paymentsTable', payments, ['id', 'booking', 'customer', 'amount', 'method', 'status', 'date']);
    }

    async loadFeedback() {
        const feedback = [
            { id: 1, customer: 'John Smith', provider: 'Alex Johnson', rating: 5, comment: 'Excellent service!', date: '2023-12-01' },
            { id: 2, customer: 'Sarah Lee', provider: 'Maria Garcia', rating: 4, comment: 'Good but a bit late', date: '2023-12-01' },
            { id: 3, customer: 'Mike Johnson', provider: 'David Chen', rating: 5, comment: 'Very professional', date: '2023-12-02' }
        ];
        
        this.renderTable('feedbackTable', feedback, ['customer', 'provider', 'rating', 'comment', 'date']);
    }

    async loadTickets() {
        const tickets = [
            { id: 'TICK-001', customer: 'John Smith', subject: 'Service quality issue', priority: 'high', status: 'open', created: '2023-12-01' },
            { id: 'TICK-002', customer: 'Sarah Lee', subject: 'Payment problem', priority: 'medium', status: 'in-progress', created: '2023-12-01' },
            { id: 'TICK-003', customer: 'Mike Johnson', subject: 'Booking modification', priority: 'low', status: 'resolved', created: '2023-12-02' }
        ];
        
        this.renderTable('ticketsTable', tickets, ['id', 'customer', 'subject', 'priority', 'status', 'created']);
    }

    async loadDashboardData() {
        // Load activity feed
        const activities = [
            { type: 'user', text: 'New user John Doe registered', time: '2 mins ago' },
            { type: 'booking', text: 'Booking #BKT-7894 created', time: '15 mins ago' },
            { type: 'payment', text: 'Payment of $150 received', time: '1 hour ago' },
            { type: 'review', text: 'New 5-star review received', time: '2 hours ago' }
        ];
        
        const activityFeed = document.getElementById('activityFeed');
        if (activityFeed) {
            activityFeed.innerHTML = activities.map(activity => `
                <div class="activity-item">
                    <div class="activity-icon ${activity.type}">
                        <i class="fas fa-${this.getActivityIcon(activity.type)}"></i>
                    </div>
                    <div class="activity-content">
                        <p>${activity.text}</p>
                        <small>${activity.time}</small>
                    </div>
                </div>
            `).join('');
        }
        
        // Load today's bookings
        const todayBookings = document.getElementById('todayBookings');
        if (todayBookings) {
            const bookings = [
                { id: 'BKT-7894', service: 'Plumbing', customer: 'John Smith', time: '10:30 AM', status: 'confirmed' },
                { id: 'BKT-7893', service: 'Electrical', customer: 'Sarah Lee', time: '11:00 AM', status: 'in-progress' }
            ];
            
            todayBookings.innerHTML = bookings.map(booking => `
                <tr>
                    <td>${booking.id}</td>
                    <td>${booking.service}</td>
                    <td>${booking.customer}</td>
                    <td>${booking.time}</td>
                    <td><span class="status-badge ${booking.status}">${booking.status}</span></td>
                    <td><button class="btn-small" onclick="admin.viewBooking('${booking.id}')">View</button></td>
                </tr>
            `).join('');
        }
    }

    getActivityIcon(type) {
        const icons = {
            user: 'user-plus',
            booking: 'calendar-plus',
            payment: 'credit-card',
            review: 'star',
            provider: 'user-tie',
            service: 'concierge-bell'
        };
        return icons[type] || 'bell';
    }

    renderTable(tableId, data, columns) {
        const table = document.getElementById(tableId);
        if (!table) return;
        
        const tbody = table.querySelector('tbody');
        if (!tbody) return;
        
        tbody.innerHTML = data.map(item => `
            <tr>
                ${columns.map(col => `
                    <td>${item[col] || ''}</td>
                `).join('')}
                <td class="actions">
                    <button class="btn-icon" onclick="admin.editItem('${tableId}', ${item.id})" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-icon" onclick="admin.deleteItem('${tableId}', ${item.id})" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="btn-icon" onclick="admin.viewDetails('${tableId}', ${item.id})" title="View">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    initEventListeners() {
        // Quick action buttons
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action || e.currentTarget.querySelector('span').textContent;
                this.handleQuickAction(action);
            });
        });
        
        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const filter = e.currentTarget.dataset.filter;
                this.applyFilter(filter);
            });
        });
        
        // Export buttons
        document.querySelectorAll('.export-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const type = e.currentTarget.dataset.type || 'csv';
                this.exportData(type);
            });
        });
        
        // Status change handlers
        document.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const id = e.target.dataset.id;
                const status = e.target.value;
                this.updateStatus(id, status);
            });
        });
    }

    handleQuickAction(action) {
        switch(action.toLowerCase()) {
            case 'add service':
                this.openModal('addService');
                break;
            case 'add provider':
                this.openModal('addProvider');
                break;
            case 'add user':
                this.openModal('addUser');
                break;
            case 'export report':
                this.exportReport();
                break;
            case 'send notification':
                this.openModal('sendNotification');
                break;
            default:
                console.log('Action:', action);
        }
    }

    applyFilter(filter) {
        console.log('Applying filter:', filter);
        // In real app, filter data and re-render
    }

    exportData(type) {
        const data = ''; // Get data based on current page
        const filename = `export-${new Date().toISOString().split('T')[0]}.${type}`;
        
        const blob = new Blob([data], { type: `text/${type}` });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        
        this.showToast(`Exported as ${type.toUpperCase()}`, 'success');
    }

    updateStatus(id, status) {
        // Simulate API call
        setTimeout(() => {
            this.showToast(`Status updated to ${status}`, 'success');
        }, 500);
    }

    exportReport() {
        this.showConfirmation('Export Report', 'Export dashboard report as CSV?', () => {
            // Generate CSV data
            const csvData = 'Report,Data\nDashboard,Export\nDate,' + new Date().toISOString();
            const blob = new Blob([csvData], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `qss-report-${new Date().toISOString().split('T')[0]}.csv`;
            a.click();
            
            this.showToast('Report exported successfully!', 'success');
        });
    }

    viewBooking(id) {
        window.location.href = `admin-booking-details.html?id=${id}`;
    }

    editItem(tableId, itemId) {
        console.log('Edit', tableId, itemId);
        // Open edit modal or redirect to edit page
    }

    deleteItem(tableId, itemId) {
        this.showConfirmation('Delete Item', 'Are you sure you want to delete this item?', () => {
            // Simulate deletion
            setTimeout(() => {
                this.showToast('Item deleted successfully!', 'success');
                // Refresh table
                this.loadPageData();
            }, 1000);
        });
    }

    viewDetails(tableId, itemId) {
        const pageMap = {
            'usersTable': 'admin-user-details.html',
            'providersTable': 'admin-provider-details.html',
            'servicesTable': 'admin-service-details.html',
            'bookingsTable': 'admin-booking-details.html',
            'paymentsTable': 'admin-payment-details.html',
            'feedbackTable': 'admin-feedback-details.html',
            'ticketsTable': 'admin-ticket-details.html'
        };
        
        const page = pageMap[tableId];
        if (page) {
            window.location.href = `${page}?id=${itemId}`;
        }
    }

    // Modal functions
    openModal(modalId) {
        const modal = document.getElementById(`${modalId}Modal`);
        if (modal) {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(`${modalId}Modal`);
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }

    showConfirmation(title, message, onConfirm) {
        const modal = document.getElementById('confirmationModal');
        const titleEl = document.getElementById('confirmationTitle');
        const messageEl = document.getElementById('confirmationMessage');
        const confirmBtn = document.getElementById('confirmActionBtn');
        
        if (modal && titleEl && messageEl && confirmBtn) {
            titleEl.textContent = title;
            messageEl.textContent = message;
            
            // Remove previous listeners
            const newConfirmBtn = confirmBtn.cloneNode(true);
            confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
            
            newConfirmBtn.addEventListener('click', () => {
                this.closeModal('confirmation');
                if (onConfirm) onConfirm();
            });
            
            this.openModal('confirmation');
        }
    }

    showToast(message, type = 'info') {
        // Create toast container if it doesn't exist
        let container = document.getElementById('toastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toastContainer';
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        
        // Create toast
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas fa-${this.getToastIcon(type)}"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
        `;
        
        container.appendChild(toast);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.animation = 'slideOut 0.3s forwards';
                setTimeout(() => toast.remove(), 300);
            }
        }, 5000);
    }

    getToastIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }
}

// Utility function for debouncing
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize admin dashboard
let admin = null;
document.addEventListener('DOMContentLoaded', () => {
    admin = new AdminDashboard();
});
// Make service cards clickable
document.addEventListener('DOMContentLoaded', function() {
    // Service cards click functionality
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
        card.addEventListener('click', function(e) {
            // Don't trigger if clicking on a link inside the card
            if (e.target.tagName === 'A' || e.target.closest('a')) {
                return;
            }
            
            // Get the service link
            const link = this.querySelector('a');
            if (link) {
                window.location.href = link.getAttribute('href');
            }
        });
    });
    
    // Remove any existing mobile menu functionality
    const mobileMenu = document.querySelector('.mobile-menu');
    if (mobileMenu) {
        mobileMenu.style.display = 'none';
    }
    
    // Remove mobile menu event listeners if they exist
    const navLinks = document.querySelector('.nav-links');
    if (navLinks) {
        navLinks.classList.remove('active');
    }
});
// Add this function to admin.js to handle quick actions
function initQuickActions() {
    // Add Service Button
    const addServiceBtn = document.getElementById('addServiceBtn');
    if (addServiceBtn) {
        addServiceBtn.addEventListener('click', function() {
            showAddServiceModal();
        });
    }

    // Add Provider Button
    const addProviderBtn = document.getElementById('addProviderBtn');
    if (addProviderBtn) {
        addProviderBtn.addEventListener('click', function() {
            showAddProviderModal();
        });
    }

    // Add User Button
    const addUserBtn = document.getElementById('addUserBtn');
    if (addUserBtn) {
        addUserBtn.addEventListener('click', function() {
            showAddUserModal();
        });
    }

    // Add Category Button
    const addCategoryBtn = document.getElementById('addCategoryBtn');
    if (addCategoryBtn) {
        addCategoryBtn.addEventListener('click', function() {
            showAddCategoryModal();
        });
    }

    // Export Report Button
    const exportReportBtn = document.getElementById('exportReportBtn');
    if (exportReportBtn) {
        exportReportBtn.addEventListener('click', function() {
            exportReport();
        });
    }

    // Send Notification Button
    const sendNotificationBtn = document.getElementById('sendNotificationBtn');
    if (sendNotificationBtn) {
        sendNotificationBtn.addEventListener('click', function() {
            showSendNotificationModal();
        });
    }

    // View Tickets Button
    const viewTicketsBtn = document.getElementById('viewTicketsBtn');
    if (viewTicketsBtn) {
        viewTicketsBtn.addEventListener('click', function() {
            window.location.href = 'admin-tickets.html';
        });
    }

    // System Settings Button
    const systemSettingsBtn = document.getElementById('systemSettingsBtn');
    if (systemSettingsBtn) {
        systemSettingsBtn.addEventListener('click', function() {
            window.location.href = 'admin-settings.html';
        });
    }
}

// Add Service Modal Function
function showAddServiceModal() {
    const modalHTML = `
        <div class="modal" id="addServiceModal" style="display: flex;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-plus"></i> Add New Service</h3>
                    <button class="modal-close" onclick="closeModal('addService')">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="addServiceForm">
                        <div class="form-group">
                            <label>Service Name *</label>
                            <input type="text" id="serviceName" placeholder="Enter service name" required>
                        </div>
                        <div class="form-group">
                            <label>Category *</label>
                            <select id="serviceCategory" required>
                                <option value="">Select category</option>
                                <option value="plumbing">Plumbing</option>
                                <option value="electrical">Electrical</option>
                                <option value="cleaning">Cleaning</option>
                                <option value="home-repair">Home Repair</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea id="serviceDescription" placeholder="Enter service description" rows="3"></textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Base Price ($) *</label>
                                <input type="number" id="servicePrice" placeholder="0.00" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label>Duration (hours)</label>
                                <input type="number" id="serviceDuration" placeholder="2" min="1" max="24">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Status *</label>
                            <select id="serviceStatus" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn-secondary" onclick="closeModal('addService')">Cancel</button>
                            <button type="submit" class="btn-primary">Add Service</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add form submit handler
    const form = document.getElementById('addServiceForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        addNewService();
    });
}

// Add Provider Modal Function
function showAddProviderModal() {
    const modalHTML = `
        <div class="modal" id="addProviderModal" style="display: flex;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-user-plus"></i> Add New Provider</h3>
                    <button class="modal-close" onclick="closeModal('addProvider')">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="addProviderForm">
                        <div class="form-row">
                            <div class="form-group">
                                <label>First Name *</label>
                                <input type="text" id="providerFirstName" placeholder="First name" required>
                            </div>
                            <div class="form-group">
                                <label>Last Name *</label>
                                <input type="text" id="providerLastName" placeholder="Last name" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Email *</label>
                            <input type="email" id="providerEmail" placeholder="provider@example.com" required>
                        </div>
                        <div class="form-group">
                            <label>Phone *</label>
                            <input type="tel" id="providerPhone" placeholder="Phone number" required>
                        </div>
                        <div class="form-group">
                            <label>Service Category *</label>
                            <select id="providerService" required>
                                <option value="">Select service</option>
                                <option value="plumbing">Plumbing</option>
                                <option value="electrical">Electrical</option>
                                <option value="cleaning">Cleaning</option>
                                <option value="home-repair">Home Repair</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Experience (years)</label>
                            <input type="number" id="providerExperience" placeholder="0" min="0" max="50">
                        </div>
                        <div class="form-group">
                            <label>Hourly Rate ($)</label>
                            <input type="number" id="providerRate" placeholder="25.00" step="0.01">
                        </div>
                        <div class="form-group">
                            <label>Status *</label>
                            <select id="providerStatus" required>
                                <option value="active">Active</option>
                                <option value="pending">Pending Verification</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn-secondary" onclick="closeModal('addProvider')">Cancel</button>
                            <button type="submit" class="btn-primary">Add Provider</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const form = document.getElementById('addProviderForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        addNewProvider();
    });
}

// Add User Modal Function
function showAddUserModal() {
    const modalHTML = `
        <div class="modal" id="addUserModal" style="display: flex;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-user-plus"></i> Add New User</h3>
                    <button class="modal-close" onclick="closeModal('addUser')">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="addUserForm">
                        <div class="form-row">
                            <div class="form-group">
                                <label>First Name *</label>
                                <input type="text" id="userFirstName" placeholder="First name" required>
                            </div>
                            <div class="form-group">
                                <label>Last Name *</label>
                                <input type="text" id="userLastName" placeholder="Last name" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Email *</label>
                            <input type="email" id="userEmail" placeholder="user@example.com" required>
                        </div>
                        <div class="form-group">
                            <label>Phone</label>
                            <input type="tel" id="userPhone" placeholder="Phone number">
                        </div>
                        <div class="form-group">
                            <label>Role *</label>
                            <select id="userRole" required>
                                <option value="">Select role</option>
                                <option value="customer">Customer</option>
                                <option value="provider">Provider</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Password *</label>
                            <input type="password" id="userPassword" placeholder="Password" required>
                            <small>Minimum 8 characters</small>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password *</label>
                            <input type="password" id="userConfirmPassword" placeholder="Confirm password" required>
                        </div>
                        <div class="form-group">
                            <label>Status *</label>
                            <select id="userStatus" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn-secondary" onclick="closeModal('addUser')">Cancel</button>
                            <button type="submit" class="btn-primary">Add User</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const form = document.getElementById('addUserForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        addNewUser();
    });
}

// Add Category Modal Function
function showAddCategoryModal() {
    const modalHTML = `
        <div class="modal" id="addCategoryModal" style="display: flex;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-list-alt"></i> Add New Category</h3>
                    <button class="modal-close" onclick="closeModal('addCategory')">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="addCategoryForm">
                        <div class="form-group">
                            <label>Category Name *</label>
                            <input type="text" id="categoryName" placeholder="Enter category name" required>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea id="categoryDescription" placeholder="Enter category description" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label>Icon Class</label>
                            <input type="text" id="categoryIcon" placeholder="fas fa-icon (FontAwesome class)">
                            <small>Example: fas fa-tools, fas fa-plug</small>
                        </div>
                        <div class="form-group">
                            <label>Status *</label>
                            <select id="categoryStatus" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn-secondary" onclick="closeModal('addCategory')">Cancel</button>
                            <button type="submit" class="btn-primary">Add Category</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const form = document.getElementById('addCategoryForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        addNewCategory();
    });
}

// Send Notification Modal Function
function showSendNotificationModal() {
    const modalHTML = `
        <div class="modal" id="sendNotificationModal" style="display: flex;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-bell"></i> Send Notification</h3>
                    <button class="modal-close" onclick="closeModal('sendNotification')">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="sendNotificationForm">
                        <div class="form-group">
                            <label>Recipient Type *</label>
                            <select id="recipientType" required>
                                <option value="">Select recipient type</option>
                                <option value="all">All Users</option>
                                <option value="customers">Customers Only</option>
                                <option value="providers">Providers Only</option>
                                <option value="specific">Specific Users</option>
                            </select>
                        </div>
                        <div class="form-group" id="specificUsersContainer" style="display: none;">
                            <label>Select Users</label>
                            <select id="specificUsers" multiple style="height: 100px;">
                                <option value="1">John Doe (Customer)</option>
                                <option value="2">Jane Smith (Customer)</option>
                                <option value="3">Alex Johnson (Provider)</option>
                                <option value="4">Maria Garcia (Provider)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Title *</label>
                            <input type="text" id="notificationTitle" placeholder="Notification title" required>
                        </div>
                        <div class="form-group">
                            <label>Message *</label>
                            <textarea id="notificationMessage" placeholder="Enter your message" rows="4" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Priority</label>
                            <select id="notificationPriority">
                                <option value="normal">Normal</option>
                                <option value="high">High</option>
                                <option value="urgent">Urgent</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn-secondary" onclick="closeModal('sendNotification')">Cancel</button>
                            <button type="submit" class="btn-primary">Send Notification</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const form = document.getElementById('sendNotificationForm');
    const recipientType = document.getElementById('recipientType');
    const specificUsersContainer = document.getElementById('specificUsersContainer');
    
    recipientType.addEventListener('change', function() {
        specificUsersContainer.style.display = this.value === 'specific' ? 'block' : 'none';
    });
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        sendNotification();
    });
}

// Function to add new service
function addNewService() {
    const serviceName = document.getElementById('serviceName').value;
    const serviceCategory = document.getElementById('serviceCategory').value;
    const serviceDescription = document.getElementById('serviceDescription').value;
    const servicePrice = document.getElementById('servicePrice').value;
    const serviceDuration = document.getElementById('serviceDuration').value;
    const serviceStatus = document.getElementById('serviceStatus').value;
    
    if (!serviceName || !serviceCategory || !servicePrice) {
        alert('Please fill in all required fields');
        return;
    }
    
    // Show loading
    const submitBtn = document.querySelector('#addServiceForm .btn-primary');
    const originalText = submitBtn.textContent;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
    submitBtn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Show success message
        showToast(`Service "${serviceName}" added successfully!`, 'success');
        
        // Close modal
        closeModal('addService');
        
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        
        // Refresh services list if on services page
        if (window.location.pathname.includes('admin-services')) {
            window.location.reload();
        }
    }, 1500);
}

// Function to add new provider
function addNewProvider() {
    const firstName = document.getElementById('providerFirstName').value;
    const lastName = document.getElementById('providerLastName').value;
    const email = document.getElementById('providerEmail').value;
    const phone = document.getElementById('providerPhone').value;
    const service = document.getElementById('providerService').value;
    
    if (!firstName || !lastName || !email || !phone || !service) {
        alert('Please fill in all required fields');
        return;
    }
    
    // Show loading
    const submitBtn = document.querySelector('#addProviderForm .btn-primary');
    const originalText = submitBtn.textContent;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        showToast(`Provider "${firstName} ${lastName}" added successfully!`, 'success');
        closeModal('addProvider');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 1500);
}

// Function to add new user
function addNewUser() {
    const firstName = document.getElementById('userFirstName').value;
    const lastName = document.getElementById('userLastName').value;
    const email = document.getElementById('userEmail').value;
    const password = document.getElementById('userPassword').value;
    const confirmPassword = document.getElementById('userConfirmPassword').value;
    const role = document.getElementById('userRole').value;
    
    if (!firstName || !lastName || !email || !password || !role) {
        alert('Please fill in all required fields');
        return;
    }
    
    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
    }
    
    if (password.length < 8) {
        alert('Password must be at least 8 characters');
        return;
    }
    
    // Show loading
    const submitBtn = document.querySelector('#addUserForm .btn-primary');
    const originalText = submitBtn.textContent;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        showToast(`User "${firstName} ${lastName}" added successfully!`, 'success');
        closeModal('addUser');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 1500);
}

// Function to add new category
function addNewCategory() {
    const name = document.getElementById('categoryName').value;
    const description = document.getElementById('categoryDescription').value;
    const status = document.getElementById('categoryStatus').value;
    
    if (!name) {
        alert('Please enter category name');
        return;
    }
    
    // Show loading
    const submitBtn = document.querySelector('#addCategoryForm .btn-primary');
    const originalText = submitBtn.textContent;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        showToast(`Category "${name}" added successfully!`, 'success');
        closeModal('addCategory');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 1500);
}

// Function to send notification
function sendNotification() {
    const recipientType = document.getElementById('recipientType').value;
    const title = document.getElementById('notificationTitle').value;
    const message = document.getElementById('notificationMessage').value;
    const priority = document.getElementById('notificationPriority').value;
    
    if (!recipientType || !title || !message) {
        alert('Please fill in all required fields');
        return;
    }
    
    // Show loading
    const submitBtn = document.querySelector('#sendNotificationForm .btn-primary');
    const originalText = submitBtn.textContent;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        showToast(`Notification sent to ${recipientType === 'all' ? 'all users' : recipientType}!`, 'success');
        closeModal('sendNotification');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 1500);
}

// Export Report Function
function exportReport() {
    // Show confirmation
    if (!confirm('Export dashboard report as CSV?')) {
        return;
    }
    
    // Create CSV data
    const date = new Date().toISOString().split('T')[0];
    const csvData = [
        ['Report', 'Quick Support Services Dashboard'],
        ['Date', date],
        ['Time', new Date().toLocaleTimeString()],
        ['', ''],
        ['Metric', 'Value'],
        ['Total Users', '1,247'],
        ['Active Providers', '247'],
        ['Today\'s Bookings', '42'],
        ['Monthly Revenue', '$12,589'],
        ['Success Rate', '94.2%'],
        ['Average Rating', '4.7']
    ];
    
    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `qss-dashboard-report-${date}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    showToast('Report exported successfully!', 'success');
}

// Close modal function
function closeModal(modalId) {
    const modal = document.getElementById(`${modalId}Modal`);
    if (modal) {
        modal.remove();
    }
}

// Toast notification function
function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    
    // Create toast
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${getToastIcon(type)}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    `;
    
    container.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, 5000);
}

function getToastIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Initialize quick actions when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initQuickActions();
});

// Make admin available globally
window.admin = admin;