// JavaScript for Cleaning Service Page
document.addEventListener('DOMContentLoaded', function () {
    // Set minimum date for date picker to today
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const todayStr = `${yyyy}-${mm}-${dd}`;
    document.getElementById('date').min = todayStr;

    // Initialize booking data object
    const bookingData = {
        service: '',
        price: 0,
        date: '',
        time: '',
        propertySize: '',
        name: '',
        email: '',
        contact: '',
        address: '',
        specialInstructions: ''
    };

    // Hero book now button
    document.getElementById('heroBookBtn').addEventListener('click', function () {
        document.getElementById('bookingCard').scrollIntoView({ behavior: 'smooth' });
    });

    // Service selection
    const serviceOptions = document.querySelectorAll('.service-option');
    serviceOptions.forEach(option => {
        option.addEventListener('click', function () {
            serviceOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');

            bookingData.service = this.querySelector('h5').textContent;
            bookingData.price = parseInt(this.getAttribute('data-price'));

            document.querySelector('.amount').textContent = bookingData.price;
        });
    });

    // Property size selection
    const propertySizeSelect = document.getElementById('propertySize');
    propertySizeSelect.addEventListener('change', function () {
        bookingData.propertySize = this.options[this.selectedIndex].text;
        if (bookingData.service && bookingData.price) {
            adjustPriceByPropertySize();
        }
    });

    function adjustPriceByPropertySize() {
        const size = propertySizeSelect.value;
        let multiplier = 1;

        switch (size) {
            case '1bhk': multiplier = 0.8; break;
            case '2bhk': multiplier = 1; break;
            case '3bhk': multiplier = 1.3; break;
            case '4bhk': multiplier = 1.6; break;
            case 'custom': multiplier = 2; break;
        }

        const basePrice = parseInt(document.querySelector('.service-option.active').getAttribute('data-price'));
        bookingData.price = Math.round(basePrice * multiplier);
        document.querySelector('.amount').textContent = bookingData.price;
    }

    // Step navigation
    const steps = document.querySelectorAll('.booking-step');
    const progressSteps = document.querySelectorAll('.progress-step');
    let currentStep = 1;

    document.querySelectorAll('.btn-next').forEach(button => {
        button.addEventListener('click', function () {
            const nextStep = parseInt(this.getAttribute('data-next'));
            if (validateStep(currentStep)) {
                document.querySelector(`.progress-step[data-step="${currentStep}"]`).classList.remove('active');
                document.querySelector(`.progress-step[data-step="${nextStep}"]`).classList.add('active');
                document.getElementById(`step${currentStep}`).classList.remove('active');
                document.getElementById(`step${nextStep}`).classList.add('active');
                if (nextStep === 4) updateSummary();
                currentStep = nextStep;
            }
        });
    });

    document.querySelectorAll('.btn-prev').forEach(button => {
        button.addEventListener('click', function () {
            const prevStep = parseInt(this.getAttribute('data-prev'));
            document.querySelector(`.progress-step[data-step="${currentStep}"]`).classList.remove('active');
            document.querySelector(`.progress-step[data-step="${prevStep}"]`).classList.add('active');
            document.getElementById(`step${currentStep}`).classList.remove('active');
            document.getElementById(`step${prevStep}`).classList.add('active');
            currentStep = prevStep;
        });
    });

    // Validation
    function validateStep(step) {
        switch (step) {
            case 1:
                if (!bookingData.service) {
                    alert('Please select a cleaning service type');
                    return false;
                }
                return true;
            case 2:
                const date = document.getElementById('date').value;
                const time = document.getElementById('timeSlot').value;
                if (!date) { alert('Please select a date'); return false; }
                if (!time) { alert('Please select a time slot'); return false; }
                bookingData.date = date;
                bookingData.time = time;
                bookingData.propertySize = document.getElementById('propertySize').options[document.getElementById('propertySize').selectedIndex].text;
                return true;
            case 3:
                const name = document.getElementById('name').value.trim();
                const email = document.getElementById('email').value.trim();
                const contact = document.getElementById('contact').value.trim();
                const address = document.getElementById('address').value.trim();
                if (name.length < 2) { alert('Please enter your full name'); return false; }
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) { alert('Please enter a valid email address'); return false; }
                const phoneRegex = /^[6-9]\d{9}$/;
                if (!phoneRegex.test(contact)) { alert('Please enter a valid 10-digit mobile number'); return false; }
                if (address.length < 10) { alert('Please enter a complete address'); return false; }
                bookingData.name = name;
                bookingData.email = email;
                bookingData.contact = contact;
                bookingData.address = address;
                bookingData.specialInstructions = document.getElementById('specialInstructions').value.trim();
                return true;
            default:
                return true;
        }
    }

    // Update order summary
    function updateSummary() {
        document.getElementById('summary-service').textContent = bookingData.service;
        document.getElementById('summary-size').textContent = bookingData.propertySize;
        document.getElementById('summary-datetime').textContent = `${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}`;
        document.getElementById('summary-amount').textContent = `₹${bookingData.price}`;
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    }

    function getTimeSlotText(timeValue) {
        const timeSlots = {
            '8-11': '8:00 AM - 11:00 AM',
            '11-2': '11:00 AM - 2:00 PM',
            '2-5': '2:00 PM - 5:00 PM',
            '5-8': '5:00 PM - 8:00 PM'
        };
        return timeSlots[timeValue] || timeValue;
    }

    // Payment options
    const paymentOptions = document.querySelectorAll('input[name="payment"]');
    const cardDetails = document.getElementById('cardDetails');
    const upiDetails = document.getElementById('upiDetails');

    paymentOptions.forEach(option => {
        option.addEventListener('change', function () {
            if (this.value === 'card') {
                cardDetails.style.display = 'block';
                upiDetails.style.display = 'none';
            } else if (this.value === 'upi') {
                cardDetails.style.display = 'none';
                upiDetails.style.display = 'block';
            } else {
                cardDetails.style.display = 'none';
                upiDetails.style.display = 'none';
            }
        });
    });

    document.getElementById('upiMethod').addEventListener('change', function () {
        document.getElementById('upiQrSection').style.display = this.value === 'qr' ? 'block' : 'none';
        document.getElementById('upiIdSection').style.display = this.value === 'id' ? 'block' : 'none';
    });

    // Confirm payment
    document.getElementById('confirmPayment').addEventListener('click', function () {
        const selectedPayment = document.querySelector('input[name="payment"]:checked').value;

        if (selectedPayment === 'card') {
            const cardNumber = document.getElementById('cardNumber').value.trim();
            const expiry = document.getElementById('expiry').value.trim();
            const cvv = document.getElementById('cvv').value.trim();
            const cardName = document.getElementById('cardName').value.trim();
            if (!cardNumber || cardNumber.length < 16) { alert('Please enter a valid card number'); return; }
            if (!expiry || !/^\d{2}\/\d{2}$/.test(expiry)) { alert('Please enter a valid expiry date (MM/YY)'); return; }
            if (!cvv || cvv.length < 3) { alert('Please enter a valid CVV'); return; }
            if (!cardName) { alert('Please enter the name on card'); return; }
        }

        if (selectedPayment === 'upi') {
            const method = document.getElementById('upiMethod').value;
            if (!method) { alert('Please select UPI method'); return; }
            if (method === 'id') {
                const upiId = document.getElementById('upiId').value.trim();
                const upiRegex = /^[\w.-]{2,}@[a-zA-Z]{2,}$/;
                if (!upiRegex.test(upiId)) { alert('Please enter a valid UPI ID (e.g., name@upi)'); return; }
            }
        }

        localStorage.setItem('cleaningBookingData', JSON.stringify(bookingData));
        this.textContent = 'Processing...';
        this.disabled = true;

        setTimeout(() => { showConfirmation(); }, 2000);
    });

    // Confirmation view with PDF receipt
    function showConfirmation() {
        const card = document.getElementById('bookingCard');
        card.innerHTML = `
            <div class="confirmation-step">
                <i class="fas fa-check-circle confirmation-icon"></i>
                <h3>Payment Successful!</h3>
                <p>Thank you, ${bookingData.name}. Your cleaning service is booked.</p>
                <div class="confirmation-details">
                    <p><strong>Service:</strong> ${bookingData.service}</p>
                    <p><strong>Property Size:</strong> ${bookingData.propertySize}</p>
                    <p><strong>Date & Time:</strong> ${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}</p>
                    <p><strong>Amount Paid:</strong> ₹${bookingData.price}</p>
                    <p><strong>Address:</strong> ${bookingData.address}</p>
                </div>
                <button class="btn-download" id="downloadReceipt">Download Receipt</button>
                <button class="btn-cancel" id="cancelBookingBtn">Cancel Booking</button>
                <button class="btn-reschedule" id="rescheduleBookingBtn">Reschedule</button>
                <a href="/" class="btn-home">Go to Home</a>
            </div>
        `;
        attachCancelReschedule();
        document.getElementById('downloadReceipt').addEventListener('click', downloadReceiptPDF);

        function downloadReceiptPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            doc.setFontSize(18);
            doc.setTextColor(40, 40, 40);
            doc.text("Quick Support Services", 20, 20);
            doc.setFontSize(12);
            doc.text("Cleaning Service Receipt", 20, 28);

            doc.setDrawColor(150);
            doc.line(20, 32, 190, 32);

            doc.setFontSize(12);
            doc.text(`Customer: ${bookingData.name}`, 20, 45);
            doc.text(`Email: ${bookingData.email}`, 20, 52);
            doc.text(`Contact: ${bookingData.contact}`, 20, 59);

            doc.text(`Service: ${bookingData.service}`, 20, 72);
            doc.text(`Property Size: ${bookingData.propertySize}`, 20, 79);
            doc.text(`Date & Time: ${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}`, 20, 86);
            doc.text(`Address: ${bookingData.address}`, 20, 93, { maxWidth: 170 });

            doc.setFontSize(14);
            doc.text(`Amount Paid: ₹${bookingData.price}`, 20, 110);

            doc.setFontSize(10);
            doc.setTextColor(100);
            doc.text("Thank you for choosing Quick Support Services!", 20, 130);

            doc.save("Cleaning_Receipt.pdf");
        };
    }

    // CANCEL & RESCHEDULE HANDLER 
    function attachCancelReschedule() {
        const cancelBtn = document.getElementById('cancelBookingBtn');
        const rescheduleBtn = document.getElementById('rescheduleBookingBtn');

        if (cancelBtn) cancelBtn.addEventListener('click', () => {
            if (confirm("Are you sure you want to cancel this booking?")) {
                localStorage.removeItem('cleaningBookingData');
                alert("Booking canceled!");
                window.location.reload();
            }
        });

        if (rescheduleBtn) rescheduleBtn.addEventListener('click', () => {
            showRescheduleForm();
        });
    }

    function showRescheduleForm() {
        const card = document.getElementById('bookingCard');
        card.innerHTML = `
            <div class="reschedule-form">
                <h3>Reschedule Booking</h3>
                <label for="newDate">Select New Date:</label>
                <input type="date" id="newDate" min="${todayStr}" value="${bookingData.date}">
                <label for="newTime">Select New Time Slot:</label>
                <select id="newTime">
                    <option value="8-11" ${bookingData.time==='8-11'?'selected':''}>8:00 AM - 11:00 AM</option>
                    <option value="11-2" ${bookingData.time==='11-2'?'selected':''}>11:00 AM - 2:00 PM</option>
                    <option value="2-5" ${bookingData.time==='2-5'?'selected':''}>2:00 PM - 5:00 PM</option>
                    <option value="5-8" ${bookingData.time==='5-8'?'selected':''}>5:00 PM - 8:00 PM</option>
                </select>
                <button id="confirmReschedule" class="btn-confirm">Confirm</button>
                <button id="cancelReschedule" class="btn-cancel">Cancel</button>
            </div>
        `;

        document.getElementById('confirmReschedule').addEventListener('click', () => {
            const newDate = document.getElementById('newDate').value;
            const newTime = document.getElementById('newTime').value;
            if (!newDate || !newTime) { alert("Select both date and time"); return; }
            bookingData.date = newDate;
            bookingData.time = newTime;
            localStorage.setItem('cleaningBookingData', JSON.stringify(bookingData));
            alert(`Booking rescheduled to ${formatDate(newDate)} | ${getTimeSlotText(newTime)}`);
            showConfirmation(); // <-- confirmation updated with new date/time
        });

        document.getElementById('cancelReschedule').addEventListener('click', () => {
            showConfirmation();
        });
    }

    // FAQ accordion
    const faqQuestions = document.querySelectorAll('.faq-question');
    faqQuestions.forEach(question => {
        question.addEventListener('click', function () {
            this.classList.toggle('active');
            const answer = this.nextElementSibling;
            answer.classList.toggle('show');
        });
    });

    // Pricing plan selection
    const planButtons = document.querySelectorAll('.btn-select');
    planButtons.forEach(button => {
        button.addEventListener('click', function () {
            const plan = this.parentElement.querySelector('h3').textContent;
            alert(`You've selected the ${plan}. You'll be redirected to booking.`);
            document.getElementById('bookingCard').scrollIntoView({ behavior: 'smooth' });
        });
    });
});
          