document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    const navUl = document.querySelector('nav ul');
    const hamburgerIcon = document.querySelector('.hamburger-icon');
    const closeIcon = document.querySelector('.close-icon');

    if (mobileMenuBtn && navUl && hamburgerIcon && closeIcon) {
        mobileMenuBtn.addEventListener('click', function() {
            const isOpening = !navUl.classList.contains('show');
            
            navUl.classList.toggle('show');
            mobileMenuBtn.classList.toggle('active');
            
            // Toggle icons
            if (isOpening) {
                hamburgerIcon.style.display = 'none';
                closeIcon.style.display = 'block';
                document.body.style.overflow = 'hidden';
            } else {
                hamburgerIcon.style.display = 'block';
                closeIcon.style.display = 'none';
                document.body.style.overflow = '';
            }
        });

        // Close mobile menu when clicking on a link
        const navItems = document.querySelectorAll('nav ul li a');
        navItems.forEach(item => {
            item.addEventListener('click', function() {
                if (navUl.classList.contains('show')) {
                    navUl.classList.remove('show');
                    mobileMenuBtn.classList.remove('active');
                    hamburgerIcon.style.display = 'block';
                    closeIcon.style.display = 'none';
                    document.body.style.overflow = '';
                }
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
            if (navUl.classList.contains('show') && 
                !navUl.contains(event.target) && 
                !mobileMenuBtn.contains(event.target)) {
                navUl.classList.remove('show');
                mobileMenuBtn.classList.remove('active');
                hamburgerIcon.style.display = 'block';
                closeIcon.style.display = 'none';
                document.body.style.overflow = '';
            }
        });
    }

    // ---------------- LOGIN VALIDATION ----------------
    // Removed client-side login validation to allow Django to handle it.

    // ---------------- SIGNUP VALIDATION ----------------
    // Removed client-side signup validation to allow Django to handle it.

    // ---------------- BOOKING FORM VALIDATION ----------------
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const serviceType = document.getElementById('serviceType').value;
            const date = document.getElementById('date').value;
            const timeSlot = document.getElementById('timeSlot').value;
            const address = document.getElementById('address').value.trim();
            const problem = document.getElementById('problem').value.trim();
            const contact = document.getElementById('contact').value.trim();

            const phoneRegex = /^[6-9]\d{9}$/;

            if (!serviceType) {
                alert('Please select a service type');
                return;
            }
            if (!date) {
                alert('Please select a date');
                return;
            }
            if (!timeSlot) {
                alert('Please select a time slot');
                return;
            }
            if (address.length < 10) {
                alert('Please enter a valid address (at least 10 characters)');
                return;
            }
            if (problem.length < 10) {
                alert('Please describe your problem in detail (min 10 characters)');
                return;
            }
            if (!phoneRegex.test(contact)) {
                alert('Please enter a valid 10-digit mobile number');
                return;
            }

            alert('Booking request submitted! We will contact you shortly.');
            this.reset();
        });
    }

    // ---------------- CONTACT FORM VALIDATION ----------------
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const message = document.getElementById('message').value.trim();

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (name.length < 2) {
                alert('Please enter your full name');
                return;
            }
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address');
                return;
            }
            if (message.length < 20) {
                alert('Message must be at least 20 characters');
                return;
            }

            alert('Thank you for your message! We will get back to you soon.');
            this.reset();
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });

    // FAQ accordion functionality for service pages
    const faqQuestions = document.querySelectorAll('.faq-question');
    faqQuestions.forEach(question => {
        question.addEventListener('click', function() {
            this.classList.toggle('active');
            const answer = this.nextElementSibling;
            if (answer) {
                answer.classList.toggle('show');
            }
        });
    });
    
    // Service card links (update your index.html service cards)
    // Example: <a href="home-repair.html" class="service-card">...</a>
    
    // Form submission for booking
    const bookingForm2 = document.querySelector('.booking-card form');
    if (bookingForm2) {
        bookingForm2.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Booking request submitted! We will contact you shortly to confirm your appointment.');
            this.reset();
        });
    }

    // Theme Toggle Functionality
    // Check for saved theme preference or use preferred color scheme
    const themeToggle = document.getElementById('themeToggle');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    
    const currentTheme = localStorage.getItem('theme');
    if (currentTheme === 'dark' || (!currentTheme && prefersDarkScheme.matches)) {
        document.body.classList.add('dark-mode');
        if (themeToggle) themeToggle.checked = true;
    }
    
    // Theme toggle event listener
    if (themeToggle) {
        themeToggle.addEventListener('change', function() {
            if (this.checked) {
                document.body.classList.add('dark-mode');
                localStorage.setItem('theme', 'dark');
            } else {
                document.body.classList.remove('dark-mode');
                localStorage.setItem('theme', 'light');
            }
        });
    }

    // greeting
    const userGreeting = document.getElementById('userGreeting');
    const loggedInUser = localStorage.getItem('loggedInUser');

    if (userGreeting && loggedInUser) {
        userGreeting.innerHTML = `
            <span class="greeting">👋 Hi, ${loggedInUser}</span>
            <a href="#" id="logoutBtn" class="logout-btn">Logout</a>
        `;

        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                localStorage.removeItem('loggedInUser');
                alert('You have been logged out.');
                window.location.reload();
            });
        }
    }

    // ---------------- FORGOT PASSWORD ----------------
    const forgotLink = document.getElementById('forgotPassword');
    if (forgotLink) {
        forgotLink.addEventListener('click', function(e) {
            e.preventDefault();

            const storedUser = JSON.parse(localStorage.getItem('registeredUser'));
            if (!storedUser) {
                alert("No user is registered yet. Please sign up first.");
                return;
            }

            const email = prompt("Enter your registered email:");
            if (email && email === storedUser.email) {
                const newPassword = prompt("Enter your new password (min 6 chars):");
                if (newPassword && newPassword.length >= 6) {
                    storedUser.password = newPassword;
                    localStorage.setItem('registeredUser', JSON.stringify(storedUser));
                    alert("Password reset successful! Please login with your new password.");
                } else {
                    alert("Password must be at least 6 characters.");
                }
            } else {
                alert("Email not found. Please try again.");
            }
        });
    }

    // ---------------- FORGOT PASSWORD FUNCTIONALITY ----------------
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('email').value.trim();
            
            // Simple validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address');
                return;
            }
            
            // Check if email exists in localStorage
            let users = JSON.parse(localStorage.getItem('users')) || [];
            const userExists = users.some(user => user.email === email);
            
            if (userExists) {
                alert('Password reset link has been sent to your email');
                window.location.href = '/login/';
            } else {
                alert('No account found with this email address');
            }
        });
    }

    // Location functionality - WITH NULL CHECKS
    const locationPopup = document.getElementById('locationPopup');
    const allowButton = document.getElementById('allowLocation');
    const denyButton = document.getElementById('denyLocation');
    
    // Only run location code if elements exist
    if (locationPopup && allowButton && denyButton) {
        // Check if we've already asked for location
        const locationAsked = localStorage.getItem('locationAsked');
        const userLocation = localStorage.getItem('userLocation');
        
        // If we haven't asked before, show the popup
        if (!locationAsked) {
            locationPopup.style.display = 'flex';
        } else if (userLocation) {
            // If we've already asked and have a location, set it
            updateLocationIndicator(userLocation);
        } else {
            // If denied previously, set default
            setDefaultLocation();
        }
        
        // Allow button event listener
        allowButton.addEventListener('click', function() {
            getLocation();
            locationPopup.style.display = 'none';
            localStorage.setItem('locationAsked', 'true');
        });
        
        // Deny button event listener
        denyButton.addEventListener('click', function() {
            setDefaultLocation();
            locationPopup.style.display = 'none';
            localStorage.setItem('locationAsked', 'true');
        });
    }

    // Helper function for safe JSON parsing
    function safeParse(key) {
        try {
            return JSON.parse(localStorage.getItem(key));
        } catch (e) {
            return null;
        }
    }

    // Location functions
    function getLocation() {
        // Show loading state
        updateLocationIndicator('Detecting location...', true);
        
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                async function(position) {
                    // Success callback - get actual location using reverse geocoding
                    try {
                        const locationName = await getLocationName(position.coords.latitude, position.coords.longitude);
                        localStorage.setItem('userLocation', locationName);
                        localStorage.setItem('userLatitude', position.coords.latitude);
                        localStorage.setItem('userLongitude', position.coords.longitude);
                        updateLocationIndicator(locationName);
                    } catch (error) {
                        console.error("Error getting location name:", error);
                        // Fallback to coordinates if reverse geocoding fails
                        const locationText = `${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`;
                        localStorage.setItem('userLocation', locationText);
                        updateLocationIndicator(locationText);
                    }
                },
                function(error) {
                    // Error callback
                    console.error("Error getting location:", error);
                    setDefaultLocation();
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 60000
                }
            );
        } else {
            console.error("Geolocation is not supported by this browser.");
            setDefaultLocation();
        }
    }
    
    // Function to get location name from coordinates using OpenStreetMap Nominatim
    async function getLocationName(lat, lng) {
        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`);
            const data = await response.json();
            
            if (data && data.address) {
                // Try to get the most specific location name available
                if (data.address.suburb) return data.address.suburb;
                if (data.address.village) return data.address.village;
                if (data.address.town) return data.address.town;
                if (data.address.city) return data.address.city;
                if (data.address.county) return data.address.county;
                if (data.address.state) return data.address.state;
                if (data.address.country) return data.address.country;
            }
            
            // Fallback to coordinates if no specific name is found
            return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
        } catch (error) {
            console.error("Reverse geocoding error:", error);
            throw error;
        }
    }
    
    // Function to set default location (India)
    function setDefaultLocation() {
        const defaultLocation = 'India';
        localStorage.setItem('userLocation', defaultLocation);
        updateLocationIndicator(defaultLocation);
    }
    
    // Function to update location indicator in header
    function updateLocationIndicator(location, isLoading = false) {
        // Check if header exists
        const headerNav = document.querySelector('nav ul');
        
        if (headerNav) {
            // Check if location indicator already exists
            let locationIndicator = document.querySelector('.location-indicator');
            
            if (!locationIndicator) {
                // Create location indicator
                locationIndicator = document.createElement('li');
                locationIndicator.className = 'location-indicator';
                
                // Find the login button to insert before it
                const loginBtn = document.querySelector('.login-btn');
                if (loginBtn && loginBtn.parentElement) {
                    headerNav.insertBefore(locationIndicator, loginBtn.parentElement);
                } else {
                    headerNav.appendChild(locationIndicator); // fallback if login button not found
                }
            }
            
            // Update the indicator content
            if (isLoading) {
                locationIndicator.innerHTML = `<span class="location-loading"></span> Detecting...`;
            } else {
                locationIndicator.innerHTML = `<i class="fas fa-map-marker-alt"></i> <span class="location-text">${location}</span>`;
                
                // Add click event to change location
                locationIndicator.addEventListener('click', function() {
                    const newLocation = prompt('Enter your location:', location);
                    if (newLocation && newLocation.trim() !== '') {
                        const formattedLocation = newLocation.trim();
                        localStorage.setItem('userLocation', formattedLocation);
                        document.querySelector('.location-text').textContent = formattedLocation;
                    }
                });
            }
        }
    }
});