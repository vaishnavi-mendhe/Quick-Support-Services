// JavaScript for the enhanced home service page
document.addEventListener('DOMContentLoaded', function () {
    // Set minimum date for date picker to today
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const todayStr = `${yyyy}-${mm}-${dd}`;
    document.getElementById('date').min = todayStr;

    // Initialize booking data object
    const bookingData = {
        service: '',
        price: 0,
        date: '',
        time: '',
        name: '',
        email: '',
        contact: '',
        address: '',
        problem: ''
    };

    // Hero book now button
    document.getElementById('heroBookBtn').addEventListener('click', function () {
        document.getElementById('bookingCard').scrollIntoView({ behavior: 'smooth' });
    });

    // Service selection
    const serviceOptions = document.querySelectorAll('.service-option');
    serviceOptions.forEach(option => {
        option.addEventListener('click', function () {
            // Remove active class from all options
            serviceOptions.forEach(opt => opt.classList.remove('active'));

            // Add active class to clicked option
            this.classList.add('active');

            // Update booking data
            bookingData.service = this.querySelector('h5').textContent;
            bookingData.price = parseInt(this.getAttribute('data-price'));

            // Update price display
            document.querySelector('.amount').textContent = bookingData.price;
        });
    });

    // Step navigation
    const steps = document.querySelectorAll('.booking-step');
    const progressSteps = document.querySelectorAll('.progress-step');
    let currentStep = 1;

    // Next button functionality
    document.querySelectorAll('.btn-next').forEach(button => {
        button.addEventListener('click', function () {
            const nextStep = parseInt(this.getAttribute('data-next'));

            // Validate current step before proceeding
            if (validateStep(currentStep)) {
                // Update progress indicators
                document.querySelector(`.progress-step[data-step="${currentStep}"]`).classList.remove('active');
                document.querySelector(`.progress-step[data-step="${nextStep}"]`).classList.add('active');

                // Hide current step, show next step
                document.getElementById(`step${currentStep}`).classList.remove('active');
                document.getElementById(`step${nextStep}`).classList.add('active');

                // Update summary if moving to payment step
                if (nextStep === 4) {
                    updateSummary();
                }

                currentStep = nextStep;
            }
        });
    });

    // Previous button functionality
    document.querySelectorAll('.btn-prev').forEach(button => {
        button.addEventListener('click', function () {
            const prevStep = parseInt(this.getAttribute('data-prev'));

            // Update progress indicators
            document.querySelector(`.progress-step[data-step="${currentStep}"]`).classList.remove('active');
            document.querySelector(`.progress-step[data-step="${prevStep}"]`).classList.add('active');

            // Hide current step, show previous step
            document.getElementById(`step${currentStep}`).classList.remove('active');
            document.getElementById(`step${prevStep}`).classList.add('active');

            currentStep = prevStep;
        });
    });

    // Form validation for each step
    function validateStep(step) {
        switch (step) {
            case 1:
                if (!bookingData.service) {
                    alert('Please select a service type');
                    return false;
                }
                return true;
            case 2:
                const date = document.getElementById('date').value;
                const time = document.getElementById('timeSlot').value;

                if (!date) {
                    alert('Please select a date');
                    return false;
                }

                if (!time) {
                    alert('Please select a time slot');
                    return false;
                }

                // Save to booking data
                bookingData.date = date;
                bookingData.time = time;
                return true;
            case 3:
                const name = document.getElementById('name').value.trim();
                const email = document.getElementById('email').value.trim();
                const contact = document.getElementById('contact').value.trim();
                const address = document.getElementById('address').value.trim();
                const problem = document.getElementById('problem').value.trim();

                // Basic validation
                if (name.length < 2) {
                    alert('Please enter your full name');
                    return false;
                }

                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    alert('Please enter a valid email address');
                    return false;
                }

                const phoneRegex = /^[6-9]\d{9}$/;
                if (!phoneRegex.test(contact)) {
                    alert('Please enter a valid 10-digit mobile number');
                    return false;
                }

                if (address.length < 10) {
                    alert('Please enter a complete address');
                    return false;
                }

                if (problem.length < 10) {
                    alert('Please describe your problem in more detail');
                    return false;
                }

                // Save to booking data
                bookingData.name = name;
                bookingData.email = email;
                bookingData.contact = contact;
                bookingData.address = address;
                bookingData.problem = problem;
                return true;
            default:
                return true;
        }
    }

    // Update order summary
    function updateSummary() {
        document.getElementById('summary-service').textContent = bookingData.service;
        document.getElementById('summary-datetime').textContent =
            `${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}`;
        document.getElementById('summary-address').textContent =
            bookingData.address.length > 30 ? bookingData.address.substring(0, 30) + '...' : bookingData.address;
        document.getElementById('summary-amount').textContent = `₹${bookingData.price}`;
    }

    // Format date for display
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            weekday: 'short',
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        });
    }

    // Get time slot text
    function getTimeSlotText(timeValue) {
        const timeSlots = {
            '9-11': '9:00 AM - 11:00 AM',
            '11-1': '11:00 AM - 1:00 PM',
            '1-3': '1:00 PM - 3:00 PM',
            '3-5': '3:00 PM - 5:00 PM',
            '5-7': '5:00 PM - 7:00 PM'
        };
        return timeSlots[timeValue] || timeValue;
    }

    // Payment options
    const paymentOptions = document.querySelectorAll('input[name="payment"]');
    const cardDetails = document.getElementById('cardDetails');
    const upiDetails = document.getElementById('upiDetails');

    paymentOptions.forEach(option => {
        option.addEventListener('change', function () {
            if (this.value === 'card') {
                cardDetails.style.display = 'block';
                upiDetails.style.display = 'none';
            } else if (this.value === 'upi') {
                cardDetails.style.display = 'none';
                upiDetails.style.display = 'block';
            } else {
                cardDetails.style.display = 'none';
                upiDetails.style.display = 'none';
            }
        });
    });

    document.getElementById('upiMethod').addEventListener('change', function () {
        document.getElementById('upiQrSection').style.display = this.value === 'qr' ? 'block' : 'none';
        document.getElementById('upiIdSection').style.display = this.value === 'id' ? 'block' : 'none';
    });

    // Confirm payment
    document.getElementById('confirmPayment').addEventListener('click', function () {
        const selectedPayment = document.querySelector('input[name="payment"]:checked').value;

        if (selectedPayment === 'card') {
            const cardNumber = document.getElementById('cardNumber').value.trim();
            const expiry = document.getElementById('expiry').value.trim();
            const cvv = document.getElementById('cvv').value.trim();
            const cardName = document.getElementById('cardName').value.trim();
            if (!cardNumber || cardNumber.length < 16) { alert('Please enter a valid card number'); return; }
            if (!expiry || !/^\d{2}\/\d{2}$/.test(expiry)) { alert('Please enter a valid expiry date (MM/YY)'); return; }
            if (!cvv || cvv.length < 3) { alert('Please enter a valid CVV'); return; }
            if (!cardName) { alert('Please enter the name on card'); return; }
        }

        if (selectedPayment === 'upi') {
            const method = document.getElementById('upiMethod').value;
            if (!method) { alert('Please select UPI method'); return; }
            if (method === 'id') {
                const upiId = document.getElementById('upiId').value.trim();
                const upiRegex = /^[\w.-]{2,}@[a-zA-Z]{2,}$/;
                if (!upiRegex.test(upiId)) { alert('Please enter a valid UPI ID (e.g., name@upi)'); return; }
            }
        }

        localStorage.setItem('cleaningBookingData', JSON.stringify(bookingData));
        this.textContent = 'Processing...';
        this.disabled = true;

        setTimeout(() => { showConfirmation(); }, 2000);
    });

    // Confirmation view with PDF receipt
    function showConfirmation() {
        const card = document.getElementById('bookingCard');
        card.innerHTML = `
            <div class="confirmation-step">
                <i class="fas fa-check-circle confirmation-icon"></i>
                <h3>Payment Successful!</h3>
                <p>Thank you, ${bookingData.name}. Your home repair service is booked.</p>
                <div class="confirmation-details">
                    <p><strong>Service:</strong> ${bookingData.service}</p>
                    <p><strong>Property Size:</strong> ${bookingData.propertySize}</p>
                    <p><strong>Date & Time:</strong> ${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}</p>
                    <p><strong>Amount Paid:</strong> ₹${bookingData.price}</p>
                    <p><strong>Address:</strong> ${bookingData.address}</p>
                </div>
                <button class="btn-download" id="downloadReceipt">Download Receipt</button>
                <button class="btn-cancel" id="cancelBookingBtn">Cancel Booking</button>
                <button class="btn-reschedule" id="rescheduleBookingBtn">Reschedule</button>
                <a href="/" class="btn-home">Go to Home</a>
            </div>
        `;
        attachCancelReschedule();

        document.getElementById('downloadReceipt').addEventListener('click', function () {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            doc.setFontSize(18);
            doc.setTextColor(40, 40, 40);
            doc.text("Quick Support Services", 20, 20);
            doc.setFontSize(12);
            doc.text("Cleaning Service Receipt", 20, 28);

            doc.setDrawColor(150);
            doc.line(20, 32, 190, 32);

            doc.setFontSize(12);
            doc.text(`Customer: ${bookingData.name}`, 20, 45);
            doc.text(`Email: ${bookingData.email}`, 20, 52);
            doc.text(`Contact: ${bookingData.contact}`, 20, 59);

            doc.text(`Service: ${bookingData.service}`, 20, 72);
            doc.text(`Date & Time: ${formatDate(bookingData.date)} | ${getTimeSlotText(bookingData.time)}`, 20, 86);
            doc.text(`Address: ${bookingData.address}`, 20, 93, { maxWidth: 170 });

            doc.setFontSize(14);
            doc.text(`Amount Paid: ₹${bookingData.price}`, 20, 110);

            doc.setFontSize(10);
            doc.setTextColor(100);
            doc.text("Thank you for choosing Quick Support Services!", 20, 130);

            doc.save("Home_Repair_Receipt.pdf");
        });
    }

    // CANCEL & RESCHEDULE HANDLER 
    function attachCancelReschedule() {
        const cancelBtn = document.getElementById('cancelBookingBtn');
        const rescheduleBtn = document.getElementById('rescheduleBookingBtn');

        if (cancelBtn) cancelBtn.addEventListener('click', () => {
            if (confirm("Are you sure you want to cancel this booking?")) {
                localStorage.removeItem('cleaningBookingData');
                alert("Booking canceled!");
                window.location.reload();
            }
        });

        if (rescheduleBtn) rescheduleBtn.addEventListener('click', () => {
            showRescheduleForm();
        });
    }

    function showRescheduleForm() {
        const card = document.getElementById('bookingCard');
        card.innerHTML = `
            <div class="reschedule-form">
                <h3>Reschedule Booking</h3>
                <label for="newDate">Select New Date:</label>
                <input type="date" id="newDate" min="${todayStr}" value="${bookingData.date}">
                <label for="newTime">Select New Time Slot:</label>
                <select id="newTime">
                    <option value="8-11" ${bookingData.time==='8-11'?'selected':''}>8:00 AM - 11:00 AM</option>
                    <option value="11-2" ${bookingData.time==='11-2'?'selected':''}>11:00 AM - 2:00 PM</option>
                    <option value="2-5" ${bookingData.time==='2-5'?'selected':''}>2:00 PM - 5:00 PM</option>
                    <option value="5-8" ${bookingData.time==='5-8'?'selected':''}>5:00 PM - 8:00 PM</option>
                </select>
                <button id="confirmReschedule" class="btn-confirm">Confirm</button>
                <button id="cancelReschedule" class="btn-cancel">Cancel</button>
            </div>
        `;

        document.getElementById('confirmReschedule').addEventListener('click', () => {
            const newDate = document.getElementById('newDate').value;
            const newTime = document.getElementById('newTime').value;
            if (!newDate || !newTime) { alert("Select both date and time"); return; }
            bookingData.date = newDate;
            bookingData.time = newTime;
            localStorage.setItem('cleaningBookingData', JSON.stringify(bookingData));
            alert(`Booking rescheduled to ${formatDate(newDate)} | ${getTimeSlotText(newTime)}`);
            showConfirmation(); // <-- confirmation updated with new date/time
        });

        document.getElementById('cancelReschedule').addEventListener('click', () => {
            showConfirmation();
        });
    }


    // FAQ accordion functionality
    const faqQuestions = document.querySelectorAll('.faq-question');
    faqQuestions.forEach(question => {
        question.addEventListener('click', function () {
            this.classList.toggle('active');
            const answer = this.nextElementSibling;
            answer.classList.toggle('show');
        });
    });

    // Pricing plan selection
    const planButtons = document.querySelectorAll('.btn-select');
    planButtons.forEach(button => {
        button.addEventListener('click', function () {
            const plan = this.parentElement.querySelector('h3').textContent;
            alert(`You've selected the ${plan}. You'll be redirected to booking.`);
            document.getElementById('bookingCard').scrollIntoView({ behavior: 'smooth' });
        });
    });

    // Feedback modal functionality
    const modal = document.getElementById('feedbackModal');
    const closeBtn = document.querySelector('.close');
    const stars = document.querySelectorAll('.rating-stars i');
    let selectedRating = 0;

    // Star rating functionality
    stars.forEach(star => {
        star.addEventListener('click', function () {
            const rating = parseInt(this.getAttribute('data-rating'));
            selectedRating = rating;

            // Update stars display
            stars.forEach(s => {
                if (parseInt(s.getAttribute('data-rating')) <= rating) {
                    s.classList.add('active');
                } else {
                    s.classList.remove('active');
                }
            });
        });
    });

    // Close modal
    closeBtn.addEventListener('click', function () {
        modal.style.display = 'none';
    });

    // Close modal if clicked outside
    window.addEventListener('click', function (event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Feedback form submission
    document.getElementById('feedbackForm').addEventListener('submit', function (e) {
        e.preventDefault();

        if (selectedRating === 0) {
            alert('Please select a rating');
            return;
        }

        const feedback = document.getElementById('feedback').value.trim();

        // Simulate feedback submission
        alert('Thank you for your feedback!');
        modal.style.display = 'none';

        // Reset form
        this.reset();
        stars.forEach(star => star.classList.remove('active'));
        selectedRating = 0;
    });

    // Show feedback modal after 5 seconds (simulating post-service)
    setTimeout(() => {
        // Check if user has recently completed a service
        const hasRecentService = localStorage.getItem('recentService');
        if (hasRecentService) {
            modal.style.display = 'block';
            localStorage.removeItem('recentService');
        }
    }, 5000);
});