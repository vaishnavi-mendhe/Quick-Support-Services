import os
import django
from django.test import Client

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
django.setup()

client = Client()

response = client.post('/signup/', {
    'fullname': 'New User Test',
    'email': 'new_user_123@example.com',
    'phone': '1234567890',
    'password': 'testpassword',
    'confirm-password': 'testpassword',
    'role': 'customer',
    'terms': 'on'
}, HTTP_HOST='127.0.0.1')

print("Status Code:", response.status_code)
if response.status_code == 200:
    print("Content preview:", response.content.decode('utf-8')[:300])
elif response.status_code == 302:
    print("Redirecting to:", response.url)
