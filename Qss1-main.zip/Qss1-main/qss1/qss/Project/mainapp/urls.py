from django.urls import path
from . import views
from . import views_admin
from . import views_provider

urlpatterns = [
    path('', views.home),
    path('login/', views.login_view),
    path('signup/', views.signup_view),
    path('about/', views.about),
    path('contact/', views.contact),
    path('services/', views.services),
    path('services/cleaning/', views.cleaning),
    path('services/plumbing/', views.plumbing),
    path('services/electricity/', views.electricity),
    path('help/', views.help_page),
    path('terms/', views.terms),
    path('privacy/', views.privacy),
    
    # Admin Routes
    path('admin-dashboard/', views_admin.admin_dashboard, name='admin_dashboard'),
    path('admin-users/', views_admin.admin_users, name='admin_users'),
    path('admin-providers/', views_admin.admin_providers, name='admin_providers'),
    path('admin-bookings/', views_admin.admin_bookings, name='admin_bookings'),
    path('admin-services/', views_admin.admin_services, name='admin_services'),
    
    # Provider Routes
    path('provider-dashboard/', views_provider.provider_dashboard, name='provider_dashboard'),
    path('provider-bookings/', views_provider.provider_bookings, name='provider_bookings'),
    path('provider-profile/', views_provider.provider_profile, name='provider_profile'),
]
