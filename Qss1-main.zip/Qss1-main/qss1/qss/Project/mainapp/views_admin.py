from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import UserProfile, ServiceCategory, Service, Provider, Booking

def is_admin(user):
    return user.is_superuser or (hasattr(user, 'profile') and user.profile.role == 'admin')

@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    context = {
        'total_users': UserProfile.objects.filter(role='customer').count(),
        'active_providers': Provider.objects.filter(status='online').count(),
        'pending_bookings': Booking.objects.filter(status='pending').count(),
    }
    return render(request, 'admin/admin.html', context)

@login_required
@user_passes_test(is_admin)
def admin_users(request):
    customers = UserProfile.objects.filter(role='customer')
    return render(request, 'admin/admin-users.html', {'customers': customers})
@login_required
@user_passes_test(is_admin)
def admin_providers(request):
    providers = Provider.objects.all()
    return render(request, 'admin/admin-providers.html', {'providers': providers})
@login_required
@user_passes_test(is_admin)
def admin_bookings(request):
    bookings = Booking.objects.all().order_classes('-created_at') if hasattr(Booking.objects.all(), 'order_classes') else Booking.objects.all().order_by('-created_at')
    return render(request, 'admin/admin-bookings.html', {'bookings': bookings})
@login_required
@user_passes_test(is_admin)
def admin_services(request):
    categories = ServiceCategory.objects.all()
    services = Service.objects.all().select_related('category')
    return render(request, 'admin/admin-services.html', {'categories': categories, 'services': services})
