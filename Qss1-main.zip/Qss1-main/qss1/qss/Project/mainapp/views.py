from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .models import UserProfile

def home(request):
    if not request.user.is_authenticated:
        return redirect('/login/')
    user_name = request.session.get('user_name')
    if hasattr(request.user, 'first_name'):
        user_name = request.user.first_name or request.user.username
    return render(request, 'index.html', {'user_name': user_name})

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        # We need username to authenticate, so let's try to find it via email
        try:
            user_obj = User.objects.get(email=email)
            username = user_obj.username
        except User.DoesNotExist:
            username = None
            
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            
            # Redirect based on role
            if hasattr(user, 'profile'):
                if user.profile.role == 'admin':
                    return redirect('/admin-dashboard/')
                elif user.profile.role == 'provider':
                    return redirect('/provider-dashboard/')
            
            # Default fallback or customer
            return redirect('/')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials', 'message': 'Invalid credentials'})
            
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('/')

def signup_view(request):
    if request.method == 'POST':
        fullname = request.POST.get('fullname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        role = request.POST.get('role')
        
        if User.objects.filter(email=email).exists() or User.objects.filter(username=email).exists():
            return render(request, 'signup.html', {'error': 'Email already registered'})
            
        try:
            # Create standard Django user
            user = User.objects.create_user(username=email, email=email, password=password, first_name=fullname)
            
            # Update the automatically created profile with the chosen role
            profile = user.profile
            profile.role = role
            profile.phone_number = phone
            profile.save()
            
            # Log the new user in
            user = authenticate(request, username=email, password=password)
            if user is not None:
                login(request, user)
                if role == 'admin':
                    return redirect('/admin-dashboard/')
                elif role == 'provider':
                    return redirect('/provider-dashboard/')
                else:
                    return redirect('/')
        except Exception as e:
            return render(request, 'signup.html', {'error': f'Registration error: {e}'})

    return render(request, 'signup.html')

def services(request):
    return render(request, 'services.html')

def cleaning(request):
    return render(request, 'cleaning.html')

def plumbing(request):
    return render(request, 'plumbing.html')

def electricity(request):
    return render(request, 'electricity.html')

def help_page(request):
    return render(request, 'help.html')

def terms(request):
    return render(request, 'terms.html')

def privacy(request):
    return render(request, 'privacy.html')
