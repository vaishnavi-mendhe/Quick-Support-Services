from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import UserProfile, Provider, Booking

def is_provider(user):
    return user.is_superuser or (hasattr(user, 'profile') and user.profile.role == 'provider')

@login_required
@user_passes_test(is_provider)
def provider_dashboard(request):
    try:
        provider = request.user.profile.provider_info
    except Provider.DoesNotExist:
        # If a provider somehow doesn't have provider_info yet (should be created on registration)
        provider = None
        
    context = {
        'provider': provider,
    }
    
    return render(request, 'provider/provider-dashboard.html', context)

@login_required
@user_passes_test(is_provider)
def provider_bookings(request):
    try:
        provider = request.user.profile.provider_info
        bookings = Booking.objects.filter(provider=provider).order_by('date', 'time')
    except Provider.DoesNotExist:
        bookings = []
        
    return render(request, 'provider/provider-bookings.html', {'bookings': bookings})

@login_required
@user_passes_test(is_provider)
def provider_profile(request):
    try:
        provider = request.user.profile.provider_info
    except Provider.DoesNotExist:
        provider = None
        
    if request.method == 'POST':
        # Simulated save handler for now
        # You'd normally process form data here: request.POST.get('status') etc.
        pass
        
    return render(request, 'provider/provider-profile.html', {'provider': provider})
