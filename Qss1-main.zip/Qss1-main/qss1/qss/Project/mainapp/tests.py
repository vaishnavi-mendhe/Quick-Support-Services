from django.test import TestCase, Client
from django.contrib.auth.models import User
from .models import UserProfile, Provider, ServiceCategory, Service

class AccessControlTests(TestCase):
    def setUp(self):
        self.client = Client()
        
        # Create Customer
        self.customer_user = User.objects.create_user(username='customer', password='password123')
        self.customer_profile = self.customer_user.profile
        self.customer_profile.role = 'customer'
        self.customer_profile.save()

        # Create Provider
        self.provider_user = User.objects.create_user(username='provider', password='password123')
        self.provider_profile = self.provider_user.profile
        self.provider_profile.role = 'provider'
        self.provider_profile.save()
        # Provider requires a provider info record for the dashboard
        self.provider_info = Provider.objects.create(user_profile=self.provider_profile)

        # Create Admin
        self.admin_user = User.objects.create_superuser(username='admin', password='password123')
        self.admin_profile = self.admin_user.profile
        self.admin_profile.role = 'admin'
        self.admin_profile.save()

    def test_unauthenticated_access_redirects(self):
        """Test that unauthenticated users are redirected to login when accessing protected routes."""
        response = self.client.get('/admin-dashboard/')
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/login/'))

        response = self.client.get('/provider-dashboard/')
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith('/login/'))

    def test_customer_access_denied(self):
        """Test that customers cannot access admin or provider routes."""
        self.client.login(username='customer', password='password123')
        
        # Accessing admin should redirect to login (due to @user_passes_test failing without raising 403, it redirects by default in Django depending on settings, usually to login)
        response = self.client.get('/admin-dashboard/')
        self.assertEqual(response.status_code, 302)
        
        response = self.client.get('/provider-dashboard/')
        self.assertEqual(response.status_code, 302)

    def test_provider_access(self):
        """Test that providers can access provider routes but not admin routes."""
        self.client.login(username='provider', password='password123')
        
        # Provider accessing provider dashboard is allowed (200 OK)
        response = self.client.get('/provider-dashboard/')
        self.assertEqual(response.status_code, 200)
        
        # Provider accessing admin dashboard is denied (redirects to login layout)
        response = self.client.get('/admin-dashboard/')
        self.assertEqual(response.status_code, 302)

    def test_admin_access(self):
        """Test that admins can access admin routes."""
        self.client.login(username='admin', password='password123')
        
        # Admin accessing admin dashboard is allowed (200 OK)
        response = self.client.get('/admin-dashboard/')
        self.assertEqual(response.status_code, 200)
        
        # Admin accessing provider dashboard is allowed (since is_superuser usually passes both or allows override, based on our function it passes if is_superuser)
        # In views_provider.py: return user.is_superuser or user.profile.role == 'provider'
        response = self.client.get('/provider-dashboard/')
        self.assertEqual(response.status_code, 200)

class LoginRedirectTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.admin_user = User.objects.create_superuser(username='admin2', password='password123')
        admin_prof = self.admin_user.profile
        admin_prof.role = 'admin'
        admin_prof.save()
        
        self.provider_user = User.objects.create_user(username='provider2', password='password123')
        prov_prof = self.provider_user.profile
        prov_prof.role = 'provider'
        prov_prof.save()

    def test_login_redirect_by_role(self):
        """Test the custom login view redirects based on role."""
        
        # We need username to authenticate, our custom views uses email.
        self.admin_user.email = 'admin@example.com'
        self.admin_user.save()
        
        self.provider_user.email = 'provider@example.com'
        self.provider_user.save()

        # Admin Login
        response = self.client.post('/login/', {'email': 'admin@example.com', 'password': 'password123'})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/admin-dashboard/')

        # Logout
        self.client.logout()

        # Provider Login
        response = self.client.post('/login/', {'email': 'provider@example.com', 'password': 'password123'})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/provider-dashboard/')
