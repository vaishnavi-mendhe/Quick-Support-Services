from django.contrib import admin
from .models import UserProfile, ServiceCategory, Service, Provider, Booking, Review, Payment

admin.site.register(UserProfile)
admin.site.register(ServiceCategory)
admin.site.register(Service)
admin.site.register(Provider)
admin.site.register(Booking)
admin.site.register(Review)
admin.site.register(Payment)
